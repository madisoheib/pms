<?php

return [

    'actions' => [

        'logout' => [
            'label' => '로그아웃',
        ],

    ],

    'welcome' => '어서오세요',

];
