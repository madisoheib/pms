<?php

return [

    'title' => ':label 編集',

    'breadcrumb' => '編集',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'キャンセル',
            ],

            'save' => [
                'label' => '保存',
            ],

        ],

    ],

    'content' => [

        'tab' => [
            'label' => '編集',
        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => '保存しました',
        ],

    ],

];
