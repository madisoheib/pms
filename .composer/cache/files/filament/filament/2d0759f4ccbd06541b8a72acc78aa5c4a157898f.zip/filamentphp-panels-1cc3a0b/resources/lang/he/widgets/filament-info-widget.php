<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => 'תיעוד',
        ],

        'open_github' => [
            'label' => 'GitHub',
        ],

    ],

];
