<?php

return [

    'title' => 'ផ្ទាំងគ្រប់គ្រងទូទៅ',

    'actions' => [

        'filter' => [

            'label' => 'តម្រង',

            'modal' => [

                'heading' => 'តម្រង',

                'actions' => [

                    'apply' => [

                        'label' => 'អនុវត្ត',

                    ],

                ],

            ],

        ],

    ],

];
