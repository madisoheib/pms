<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => '変更を保存',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => '保存しました',
        ],

    ],

];
