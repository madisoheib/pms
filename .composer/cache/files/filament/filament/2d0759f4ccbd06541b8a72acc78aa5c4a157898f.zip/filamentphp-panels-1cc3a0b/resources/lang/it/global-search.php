<?php

return [

    'field' => [
        'label' => 'Ricerca globale',
        'placeholder' => 'Ricerca',
    ],

    'no_results_message' => 'Nessun risultato trovato per la ricerca.',

];
