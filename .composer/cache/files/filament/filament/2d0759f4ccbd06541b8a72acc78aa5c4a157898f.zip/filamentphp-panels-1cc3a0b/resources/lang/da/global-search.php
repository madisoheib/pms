<?php

return [

    'field' => [
        'label' => 'Global søgning',
        'placeholder' => 'Søg',
    ],

    'no_results_message' => 'Ingen søgeresultater fundet.',

];
