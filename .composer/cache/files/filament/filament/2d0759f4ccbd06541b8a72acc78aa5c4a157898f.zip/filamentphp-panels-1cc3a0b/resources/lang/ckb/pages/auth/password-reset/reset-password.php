<?php

return [

    'title' => 'نوێکردنەوەی وشەی نهێنی',

    'heading' => 'نوێکردنەوەی وشەی نهێنی',

    'form' => [

        'email' => [
            'label' => 'ئیمەیڵ',
        ],

        'password' => [
            'label' => 'وشەی نهێنی',
            'validation_attribute' => 'وشەی نهێنی',
        ],

        'password_confirmation' => [
            'label' => 'دڵنیابوونەوەی وشەی نهێنی',
        ],

        'actions' => [

            'reset' => [
                'label' => 'نوێکردنەوەی وشەی نهێنی',
            ],

        ],

    ],

    'notifications' => [

        'throttled' => [
            'title' => 'هەوڵی نوێکردنەوەی وشەی نهێنی زۆر نێردرا',
            'body' => 'تکایە هەوڵ بدەرەوە دوای :seconds چرکە.',
        ],

    ],

];
