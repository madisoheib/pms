<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => 'ចូលមើលឯកសារ',
        ],

        'open_github' => [
            'label' => 'GitHub',
        ],

    ],

];
