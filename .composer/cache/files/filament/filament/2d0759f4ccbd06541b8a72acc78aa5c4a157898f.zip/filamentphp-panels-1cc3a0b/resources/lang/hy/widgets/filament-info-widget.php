<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => 'Փաստաթղթեր',
        ],

        'open_github' => [
            'label' => 'GitHub',
        ],

    ],

];
