<?php

return [

    'field' => [
        'label' => 'グローバル検索',
        'placeholder' => '検索',
    ],

    'no_results_message' => '検索結果が見つかりませんでした。',

];
