<?php

return [

    'single' => [

        'label' => 'Atsieti',

        'modal' => [

            'heading' => 'Atsieti :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Atsieti',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Atsieta',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Atsieti pasirinktus',

        'modal' => [

            'heading' => 'Atsieti pasirinktus :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Atsieti',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Atsieta',
            ],

        ],

    ],

];
