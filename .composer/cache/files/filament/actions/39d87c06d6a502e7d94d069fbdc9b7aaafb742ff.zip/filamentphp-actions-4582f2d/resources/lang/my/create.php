<?php

return [

    'single' => [

        'label' => 'ဖန်တီးပါ',

        'modal' => [

            'heading' => ':label ဖန်တီးပါ',

            'actions' => [

                'create' => [
                    'label' => 'ဖန်တီးပါ',
                ],

                'create_another' => [
                    'label' => 'သိမ်းဆည်းပြီး နောက်တစ်ခုကို ဖန်တီးပါ',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'သိမ်းဆည်းပြီး',
            ],

        ],

    ],

];
