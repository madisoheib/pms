<?php

return [

    'single' => [

        'label' => 'ဖျက်ပါ',

        'modal' => [

            'heading' => ':label ကိုဖျက်ပါ',

            'actions' => [

                'delete' => [
                    'label' => 'ဖျက်ပါ',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'ဖျက်ပြီးပါပြီ',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'ဖျက်ပါ',

        'modal' => [

            'heading' => 'ရွေးချယ်ထားသည့် :label (များ)အား ဖျက်ပါ',

            'actions' => [

                'delete' => [
                    'label' => 'ဖျက်ပါ',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'ဖျက်ပြီးပါပြီ',
            ],

        ],

    ],

];
