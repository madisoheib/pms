<?php

return [

    'single' => [

        'label' => 'Pisahkan',

        'modal' => [

            'heading' => 'Pisahkan :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Pisahkan',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Data berhasil dipisahkan',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Pisahkan yang dipilih',

        'modal' => [

            'heading' => 'Pisahkan :label yang dipilih',

            'actions' => [

                'dissociate' => [
                    'label' => 'Pisahkan yang dipilih',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Data berhasil dipisahkan',
            ],

        ],

    ],

];
