<?php

return [

    'single' => [

        'label' => 'Cipta',

        'modal' => [

            'heading' => 'Cipta :label',

            'actions' => [

                'create' => [
                    'label' => 'Cipta',
                ],

                'create_another' => [
                    'label' => 'Cipta dan cipta yang lain',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'Dicipta',
            ],

        ],

    ],

];
