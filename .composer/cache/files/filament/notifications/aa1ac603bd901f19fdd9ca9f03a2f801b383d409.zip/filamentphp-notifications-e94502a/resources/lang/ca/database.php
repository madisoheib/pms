<?php

return [

    'modal' => [

        'heading' => 'Notificacions',

        'actions' => [

            'clear' => [
                'label' => 'Netejar',
            ],

            'mark_all_as_read' => [
                'label' => 'Marcar tot com a llegit',
            ],

        ],

        'empty' => [
            'heading' => 'Sense notificacions',
            'description' => 'Si us plau, torna a comprovar-ho més tard.',
        ],

    ],

];
