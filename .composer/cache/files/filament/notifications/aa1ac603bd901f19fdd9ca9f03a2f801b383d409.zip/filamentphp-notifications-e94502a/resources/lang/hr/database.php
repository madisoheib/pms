<?php

return [

    'modal' => [

        'heading' => 'Obavijesti',

        'actions' => [

            'clear' => [
                'label' => 'Očisti',
            ],

            'mark_all_as_read' => [
                'label' => 'Označi sve kao pročitano',
            ],

        ],

        'empty' => [
            'heading' => 'Nema obavijesti',
            'description' => 'Molim te, provjeri ponovno kasnije.',
        ],

    ],

];
