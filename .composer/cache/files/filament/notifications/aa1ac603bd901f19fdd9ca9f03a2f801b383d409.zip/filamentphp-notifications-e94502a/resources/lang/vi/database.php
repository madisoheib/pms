<?php

return [

    'modal' => [

        'heading' => 'Thông báo',

        'actions' => [

            'clear' => [
                'label' => 'Xóa',
            ],

            'mark_all_as_read' => [
                'label' => 'Đánh dấu tất cả là đã đọc',
            ],

        ],

        'empty' => [
            'heading' => 'Không có thông báo',
            'description' => 'Vui lòng kiểm tra lại sau.',
        ],

    ],

];
