<?php

return [

    'modal' => [

        'heading' => 'Pemberitahuan',

        'actions' => [

            'clear' => [
                'label' => 'Hapus',
            ],

            'mark_all_as_read' => [
                'label' => 'Tandai semua sebagai dibaca',
            ],

        ],

        'empty' => [
            'heading' => 'Tiada pemberitahuan di sini',
            'description' => 'Sila semak semula kemudian',
        ],

    ],

];
