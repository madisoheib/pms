<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => 'نمایش :count مورد کمتر',
                'expand_list' => 'نمایش :count مورد بیشتر',
            ],

            'more_list_items' => 'و :count مورد دیگر',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'کلید',
                ],

                'value' => [
                    'label' => 'مقدار',
                ],

            ],

            'placeholder' => 'بدون ورودی',

        ],

    ],
];
