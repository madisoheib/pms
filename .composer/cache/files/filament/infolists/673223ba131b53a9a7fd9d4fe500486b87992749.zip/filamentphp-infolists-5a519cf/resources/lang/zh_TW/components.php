<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => '少顯示 :count 筆',
                'expand_list' => '多顯示 :count 筆',
            ],

            'more_list_items' => '多 :count 筆',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => '索引',
                ],

                'value' => [
                    'label' => '值',
                ],

            ],

            'placeholder' => '無項目',

        ],

    ],

];
