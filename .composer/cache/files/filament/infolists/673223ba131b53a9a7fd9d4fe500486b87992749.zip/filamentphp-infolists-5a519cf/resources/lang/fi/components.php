<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => 'Näytä :count vähemmän',
                'expand_list' => 'Näytä :count lisää',
            ],

            'more_list_items' => 'ja :count lisää',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'Avain',
                ],

                'value' => [
                    'label' => 'Arvo',
                ],

            ],

            'placeholder' => 'Ei tietueita',

        ],

    ],

];
