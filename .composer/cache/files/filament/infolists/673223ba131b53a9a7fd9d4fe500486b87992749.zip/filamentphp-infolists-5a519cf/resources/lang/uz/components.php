<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => ':countta kam ko\'rsatish',
                'expand_list' => 'Yana :counttasini k\'rsatish',
            ],

            'more_list_items' => 'va yana :countta',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'Kalit so\'zi',
                ],

                'value' => [
                    'label' => 'Qiymati',
                ],

            ],

            'placeholder' => 'Ma\'lumot yo\'q',

        ],

    ],

];
