<p
    {{ $attributes->class(['fi-ta-empty-state-description text-sm text-gray-500 dark:text-gray-400']) }}
>
    {{ $slot }}
</p>
